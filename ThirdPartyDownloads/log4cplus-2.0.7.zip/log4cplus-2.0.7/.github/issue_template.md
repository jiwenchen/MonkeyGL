Describe your problem here.

Also, provide the following information:

 - version: *version of log4cplus that manifest your problem*
 - operating system, CPU, bitness: *what are your environement's OS, CPU's, and platform's characteristics*
 - `configure` script, or CMake, etc., flags and settings: *what setting have you used to compile log4cplus outside of defaults*
 - flags and settings used by your application: *what are the settings and comipler flags used by your application, are they compatible with those used for log4cplus compilation*
 - compiler and its version: *what compiler and what versions are you using to compile log4cplus and your application*
