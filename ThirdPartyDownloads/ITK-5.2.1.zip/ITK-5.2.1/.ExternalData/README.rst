.ExternalData
=============

The ITK ``.ExternalData`` directory is an object store for the
CMake ExternalData module that ITK uses to manage test input
and baseline data.
